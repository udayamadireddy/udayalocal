import requests
import os
from functools import lru_cache

# Python script to get the Access Token Required to access the ServiceNow REST API's for
# Vulnerability Management.


#
# Return the hostname (i.e. abc123.servicenow.com) of the ServiceNow endpoint.
#
def getServiceNowHostname():
    sn_hostname = os.environ.get('SN_HOSTNAME')
    if (sn_hostname is None):
        sn_hostname = input("Enter 'Hostname': ");

    return sn_hostname

#
# Return the minimum set of headers required to access the ServiceNow REST API's.
#
def getBaseHTTPHeaders():
    headers = {"Accept": "application/json",
               "Authorization": "Bearer " + getAccessToken()}
    return headers

#
# Return the reference (sys_id) for the record in the ServiceNow that matches the request CWE ID.
#
def get_cwe_ref_by_id(cwe_id):
    url = "https://" + getServiceNowHostname() + "/api/now/table/sn_vul_cwe?sysparm_query=cwe_id%3D" + cwe_id + "&sysparm_limit=1"
    response = requests.get(url, headers=getBaseHTTPHeaders())

    # Check for HTTP codes other than 200
    if response.status_code != 200:
        raise Exception('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())

    response_json = response.json()
    result_dictionary = response_json.get('result')
    sys_id = result_dictionary[0].get('sys_id')
    return sys_id


#
# Get the OAuth Access Token required for API access.
#
@lru_cache(maxsize=32)
def getAccessToken():

    # Pull the relevant environment variables into the system.
    # If not available, prompt the user to provide on the command
    # line.
    sn_hostname = getServiceNowHostname()
    sn_client_id = os.environ.get('SN_CLIENT_ID')
    if (sn_client_id is None):
        sn_client_id = input("Enter 'Client ID': ")
    sn_client_secret = os.environ.get('SN_CLIENT_SECRET')
    if (sn_client_secret is None):
        sn_client_secret = input("Enter 'Client Secret': ")
    sn_username = os.environ.get('SN_USERNAME')
    if (sn_username is None):
        sn_username = input("Enter 'Username': ")
    sn_password = os.environ.get('SN_PASSWORD')
    if (sn_password is None):
        sn_password = input("Enter 'Password': ")

    print("----- Parameters -----")
    print(" - Hostname:      " + sn_hostname);
    print(" - Client ID:     ************")
    #print(" - Client ID:     " + sn_client_id)

    print(" - Client Secret: ************")
    #print(" - Client Secret: " + sn_client_secret)

    print(" - Username:      " + sn_username)

    print(" - Password:      ************")
    #print(" - Password:      " + sn_password)
    print("----------------------")
    print()

    # Define the ServiceNow endpoint
    url = 'https://' + sn_hostname + '/oauth_token.do'

    payload_tuples = [('grant_type',    'password'),
                      ('client_id',     sn_client_id),
                      ('client_secret', sn_client_secret),
                      ('username',      sn_username),
                      ('password',      sn_password)]

    # Set proper headers
    headers = {"Content-Type" : "application/x-www-form-urlencoded",
               "Accept"       : "application/json"}

    # Do the HTTP request
    response = requests.post(url,
                             headers = headers,
                             data    = payload_tuples)

    # Check for HTTP codes other than 200
    if response.status_code != 200:
        print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())
        exit()

    # Decode the JSON response into a dictionary and use the data
    data = response.json()
    print("ServiceNow Access Token: " + data['access_token'])

    return data['access_token'];


#
# Deletion of single record within the Central Intake table.
#
def deleteSingleRecord(sys_id, table_name):
    # Define the ServiceNow endpoint
    getURL = "https://" + getServiceNowHostname() + "/api/now/table/" + table_name + "/" \
        + sys_id

    getResponse = requests.get(getURL, headers=getBaseHTTPHeaders())

    # Check for HTTP codes other than 200
    validResponse = (getResponse.status_code == 200)
    if not validResponse:
        print('GET request failed for sys_id ' + sys_id)
        print('Status:', getResponse.status_code, 'Headers:', getResponse.headers,
              'Error Response:', getResponse.json())
        return

    # Define the ServiceNow endpoint for deletion
    deleteURL = "https://" + getServiceNowHostname() + "/api/now/table/" + table_name + "/" \
        + sys_id

    deleteResponse = requests.delete(deleteURL, headers=getBaseHTTPHeaders())

    # Check for HTTP codes other than 204 (204 = successful deletion)
    validDeletionResponse = (deleteResponse.status_code == 204)
    if not validDeletionResponse:
        print('DELETE request failed for sys_id ' + sys_id)
        print('Status:', deleteResponse.status_code, 'Headers:', deleteResponse.headers,
              'Error Response:', deleteResponse.json())
        return
    print("==> Record deleted (sys_id = " + sys_id + ")")

