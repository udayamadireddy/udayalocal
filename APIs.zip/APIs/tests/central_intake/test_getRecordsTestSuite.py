# Getting started with Pytest
# https://docs.pytest.org/en/latest/getting-started.html



# Custom import required because packages are in different folders (packages) under the root
import sys, os

sys.path.append(os.path.abspath(os.path.join('../..', 'commonvm')))
# print(sys.path)

from commonvm import core
import requests
import json


#
# Test retrieval of a single record within the Central Intake table.
#
def test_ci_getSingleRecord():

    # Define the ServiceNow endpoint
    url = "https://" + core.getServiceNowHostname() + "/api/now/table/sn_vul_ibm_central_intake?sysparm_limit=1"

    response = requests.get(url, headers=core.getBaseHTTPHeaders())

    # Check for HTTP codes other than 200
    valid_response = (response.status_code == 200)
    if not valid_response:
        print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:', response.json())
        return
    assert (valid_response)

    # Decode the JSON response into a dictionary and use the data
    # Test is to fetch non-NULL data from result.number
    response_json = response.json()
    result_dictionary = response_json.get('result')
    record_number = result_dictionary[0].get('number')
    assert (record_number is not None)


#
# Test creation of single record within the Central Intake table.
#
class TestCentralIntakeRecordCreation:

    record_sys_id = ''

    def setup_method(self):
        self.record_sys_id = ''

    def teardown_method(self):
        # Clean up: delete record
        core.deleteSingleRecord(self.record_sys_id, 'sn_vul_ibm_central_intake')

    def test_ci_createSingleRecord(self):
        # Define the ServiceNow endpoint
        url = "https://" + core.getServiceNowHostname() + "/api/now/table/sn_vul_ibm_central_intake"

        #TODO: Consider better use of constants for field names

        cwe_sys_id = core.get_cwe_ref_by_id('cwe-77')
        response = requests.post(url,
                                 headers=core.getBaseHTTPHeaders(),
                                 data="{\"u_title\":\"Spectre/Metdown 2.OH NO!\"," +
                                      "\"description\":\"This is a test description.\"," +  # +
                                      "\"u_severity\":\"0\"," +
                                      "\"u_is_product_vulnerability\":\"true\"," +
                                      "\"u_is_application_vulnerability\":\"true\"," +
                                      "\"u_is_infrastructure_vulnerability\":\"true\"," +
                                      "\"u_is_website_vulnerability\":\"true\"," +
                                      "\"u_cwe_ref\":\"" + cwe_sys_id + "\"," +
                                      "\"u_severity_justification\":\"It's a bad one....\"}")

        # Check for HTTP codes other than 200
        valid_response = (response.status_code == 201)
        if not valid_response:
            print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:', response.json())
        assert (valid_response)

        # Check fields were set properly
        response_json = response.json()
        result_dictionary = response_json.get("result")
        title_response = result_dictionary.get("u_title")
        description_response = result_dictionary.get("description")
        severity_response = result_dictionary.get("u_severity")
        product_vulnerability_response = result_dictionary.get("u_is_product_vulnerability")
        application_vulnerability_response = result_dictionary.get("u_is_application_vulnerability")
        infrastructure_vulnerability_response = result_dictionary.get("u_is_infrastructure_vulnerability")
        website_vulnerability_response = result_dictionary.get("u_is_website_vulnerability")
        cwe_ref_response = result_dictionary.get("u_cwe_ref")
        self.record_sys_id = result_dictionary.get("sys_id")
        print("==> Record created successfully with sys_id: " + self.record_sys_id)
        print(cwe_ref_response['value'])

        assert (title_response == "Spectre/Metdown 2.OH NO!")
        assert (description_response == "This is a test description.")
        assert (severity_response == "0")
        assert (product_vulnerability_response == "true")
        assert (application_vulnerability_response == "true")
        assert (infrastructure_vulnerability_response == "true")
        assert (website_vulnerability_response == "true")
        assert (cwe_ref_response['value'] == cwe_sys_id)